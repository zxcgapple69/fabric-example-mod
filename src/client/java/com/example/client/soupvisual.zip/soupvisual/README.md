# Soup Visual — Minecraft Fabric Mod

PvP visual mod inspired by [Soup Visual](https://modrinth.com/mod/soup-api).

## Features
- **Jump Circle** — Soup (purple) & Portal (cyan) styles. Press **V** to toggle
- **Custom HUD** — HP, Armor, K/D, FPS, Ping
- **Ambient Particles** — colored particles float around the player
- **Friend Highlight** — friends in tab-list glow with purple dot

## Requirements
- Minecraft **1.21.1** (Java Edition)
- [Fabric Loader](https://fabricmc.net/use/) `0.15.11+`
- [Fabric API](https://modrinth.com/mod/fabric-api)

## Build from source

### 1. Install Java 17+
Download from https://adoptium.net

### 2. Clone the repo
```bash
git clone https://github.com/yourusername/soupvisual.git
cd soupvisual
```

### 3. Build
```bash
./gradlew build
```
The `.jar` file will be in `build/libs/soupvisual-1.0.0.jar`

### 4. Install
Copy the `.jar` into your Minecraft `mods/` folder:
- **Windows:** `%appdata%\.minecraft\mods\`
- **Linux:** `~/.minecraft/mods/`
- **Mac:** `~/Library/Application Support/minecraft/mods/`

Make sure Fabric API is also in the mods folder!

## Adding friends
Open `FriendManager.java` and add usernames to the `friends` set:
```java
friends.add("YourFriendName");
```
Then rebuild with `./gradlew build`.

## Controls
| Key | Action |
|-----|--------|
| **V** | Toggle Jump Circle style (Soup / Portal) |

## Project structure
```
src/main/java/com/soupvisual/
├── SoupVisualClient.java          ← Mod entrypoint
├── client/
│   ├── FriendManager.java         ← Friend list
│   └── feature/
│       ├── JumpCircleFeature.java ← Jump circle (Soup / Portal)
│       ├── HudFeature.java        ← HUD overlay
│       └── AmbientParticleFeature.java ← Floating particles
└── mixin/
    ├── LivingEntityRendererMixin.java ← Friend highlight hook
    └── GameRendererMixin.java         ← Key input (V key)
```
