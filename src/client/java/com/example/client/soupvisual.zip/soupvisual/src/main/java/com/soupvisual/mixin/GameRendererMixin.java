package com.soupvisual.mixin;

import com.soupvisual.client.feature.JumpCircleFeature;
import net.minecraft.client.render.GameRenderer;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    private boolean vWasPressed = false;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        long window = net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle();
        boolean vPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_V) == GLFW.GLFW_PRESS;

        if (vPressed && !vWasPressed) {
            // Toggle between Soup (0) and Portal (1)
            JumpCircleFeature.style = (JumpCircleFeature.style + 1) % 2;
        }

        vWasPressed = vPressed;
    }
}
