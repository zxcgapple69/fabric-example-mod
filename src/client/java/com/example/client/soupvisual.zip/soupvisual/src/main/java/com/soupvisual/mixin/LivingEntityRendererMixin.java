package com.soupvisual.mixin;

import com.soupvisual.client.FriendManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {

    @Inject(
        method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD")
    )
    private void onRender(LivingEntity entity, float yaw, float tickDelta,
                          MatrixStack matrices, net.minecraft.client.render.VertexConsumerProvider vertexConsumers,
                          int light, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity player) {
            if (FriendManager.isFriend(player.getGameProfile().getName())) {
                // Friend detected — glow effect can be added here
                // For now we just mark them; name tag color is handled by GameRendererMixin
            }
        }
    }
}
